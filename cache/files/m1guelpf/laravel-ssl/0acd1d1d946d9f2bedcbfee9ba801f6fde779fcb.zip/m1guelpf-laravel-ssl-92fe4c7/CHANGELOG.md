# Changelog

All notable changes to `Laravel SSL` will be documented in this file

## 2.0.0 - 2017-05-11

- use an easy aproach without middleware

## 1.0.0 - 2017-02-08

- initial release
